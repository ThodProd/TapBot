package com.tapbot.app

import android.content.Context
import android.graphics.Rect
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class StepType { TAP, DOUBLE_TAP, TRIPLE_TAP, LONG_PRESS, WAIT, FIND_WORD, OPEN_APP }
enum class ButtonShape { CIRCLE, SQUARE, ROUNDED_SQUARE, STAR }
enum class VibeStyle { SHORT, MEDIUM, LONG, DOUBLE }

enum class CoordinateSource { FIXED, OCR }

data class ButtonAction(
    val id: String = UUID.randomUUID().toString(),
    var type: StepType,
    var x: Int = 0,
    var y: Int = 0,
    var longPressMs: Long = 1000L,
    var waitMs: Long = 1000L,
    var appPackage: String? = null,
    var appLabel: String? = null,
    var searchWord: String = "",
    var coordinateSource: CoordinateSource = CoordinateSource.FIXED
)

data class OcrScenario(
    val id: String = UUID.randomUUID().toString(),
    var word: String,
    val actions: MutableList<ButtonAction> = mutableListOf(),
    var enabled: Boolean = true
)

data class NamedButton(
    val id: String,
    var name: String,
    var btnX: Int = -1,
    var btnY: Int = -1,
    var sizeDp: Int = 56,
    var vibrate: Boolean = true,
    var vibeStyle: VibeStyle = VibeStyle.SHORT,
    var triggerTaps: Int = 1,
    var color: Int = PatternStore.COLOR_PALETTE[0],
    var shape: ButtonShape = ButtonShape.CIRCLE,
    var enabled: Boolean = true,
    val actions: MutableList<ButtonAction> = mutableListOf(),
    val ocrScenarios: MutableList<OcrScenario> = mutableListOf()
) {
    fun isOcr() = ocrScenarios.isNotEmpty()
}

class Pattern(var name: String, var enabled: Boolean = true, val buttons: MutableList<NamedButton> = mutableListOf())

/** Kept only for importing older TapBot files. New versions store OCR words inside the button. */
data class OcrRule(
    val id: String = UUID.randomUUID().toString(),
    var searchText: String,
    var targetPatternName: String,
    var targetButtonId: String,
    var enabled: Boolean = true
)

object PatternStore {
    private const val NAME = "tapbot_prefs"
    private const val KEY_PATTERNS = "patterns_json_v7"
    private const val KEY_BUTTON_ENABLED = "button_enabled"
    private const val KEY_ADDER_ENABLED = "adder_enabled"
    private const val KEY_ADDER_X = "adder_x"
    private const val KEY_ADDER_Y = "adder_y"
    private const val KEY_SHOW_RESIZE = "show_resize_handle"

    const val EXPORT_FORMAT_VERSION = 3

    val COLOR_PALETTE = listOf(
        0xCCDB5A21.toInt(), 0xCC216FDB.toInt(), 0xCC2FA84F.toInt(), 0xCCD93636.toInt(),
        0xCC8E44AD.toInt(), 0xCC16A085.toInt(), 0xCCE91E8C.toInt(), 0xCC333333.toInt()
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    private fun actionToJson(a: ButtonAction): JSONObject = JSONObject().apply {
        put("id", a.id); put("type", a.type.name); put("x", a.x); put("y", a.y)
        put("longPressMs", a.longPressMs); put("waitMs", a.waitMs)
        a.appPackage?.let { put("appPackage", it) }; a.appLabel?.let { put("appLabel", it) }; if (a.searchWord.isNotBlank()) put("searchWord", a.searchWord)
        put("coordinateSource", a.coordinateSource.name)
    }

    private fun actionFromJson(o: JSONObject): ButtonAction = ButtonAction(
        id = o.optString("id", UUID.randomUUID().toString()),
        type = try { StepType.valueOf(o.optString("type", "TAP")) } catch (_: Exception) { StepType.TAP },
        x = o.optInt("x", 0), y = o.optInt("y", 0),
        longPressMs = o.optLong("longPressMs", 1000L), waitMs = o.optLong("waitMs", 1000L),
        appPackage = if (o.has("appPackage")) o.optString("appPackage") else null,
        appLabel = if (o.has("appLabel")) o.optString("appLabel") else null,
        searchWord = o.optString("searchWord", ""),
        coordinateSource = try { CoordinateSource.valueOf(o.optString("coordinateSource", "FIXED")) } catch (_: Exception) { CoordinateSource.FIXED }
    )

    private fun actionsToJson(actions: List<ButtonAction>) = JSONArray().apply { actions.forEach { put(actionToJson(it)) } }
    private fun actionsFromJson(a: JSONArray?): MutableList<ButtonAction> = mutableListOf<ButtonAction>().apply {
        if (a == null) return@apply
        for (i in 0 until a.length()) a.optJSONObject(i)?.let { add(actionFromJson(it)) }
    }

    private fun scenarioToJson(s: OcrScenario) = JSONObject().apply {
        put("id", s.id); put("word", s.word); put("enabled", s.enabled); put("actions", actionsToJson(s.actions))
    }

    private fun scenarioFromJson(o: JSONObject) = OcrScenario(
        id = o.optString("id", UUID.randomUUID().toString()),
        word = o.optString("word", ""),
        actions = actionsFromJson(o.optJSONArray("actions")),
        enabled = o.optBoolean("enabled", true)
    )

    private fun patternsToJson(patterns: List<Pattern>) = JSONArray().apply {
        patterns.forEach { p -> put(JSONObject().apply {
            put("name", p.name); put("enabled", p.enabled)
            put("buttons", JSONArray().apply { p.buttons.forEach { b -> put(JSONObject().apply {
                put("id", b.id); put("name", b.name); put("btnX", b.btnX); put("btnY", b.btnY)
                put("sizeDp", b.sizeDp); put("vibrate", b.vibrate); put("vibeStyle", b.vibeStyle.name)
                put("triggerTaps", b.triggerTaps); put("color", b.color); put("shape", b.shape.name); put("enabled", b.enabled)
                put("actions", actionsToJson(b.actions))
                put("ocrScenarios", JSONArray().apply { b.ocrScenarios.forEach { put(scenarioToJson(it)) } })
            }) } })
        }) }
    }

    private fun patternsFromJson(arr: JSONArray): MutableList<Pattern> = mutableListOf<Pattern>().apply {
        for (i in 0 until arr.length()) {
            val po = arr.optJSONObject(i) ?: continue
            val buttons = mutableListOf<NamedButton>()
            val ba = po.optJSONArray("buttons") ?: JSONArray()
            for (j in 0 until ba.length()) {
                val o = ba.optJSONObject(j) ?: continue
                val b = NamedButton(
                    id = o.optString("id", UUID.randomUUID().toString()), name = o.optString("name", "Кнопка"),
                    btnX = o.optInt("btnX", -1), btnY = o.optInt("btnY", -1), sizeDp = o.optInt("sizeDp", 56),
                    vibrate = o.optBoolean("vibrate", true),
                    vibeStyle = try { VibeStyle.valueOf(o.optString("vibeStyle", VibeStyle.SHORT.name)) } catch (_: Exception) { VibeStyle.SHORT },
                    triggerTaps = o.optInt("triggerTaps", 1).coerceIn(1, 3), color = o.optInt("color", COLOR_PALETTE[0]),
                    shape = try { ButtonShape.valueOf(o.optString("shape", ButtonShape.CIRCLE.name)) } catch (_: Exception) { ButtonShape.CIRCLE },
                    enabled = o.optBoolean("enabled", true), actions = actionsFromJson(o.optJSONArray("actions"))
                )
                val sa = o.optJSONArray("ocrScenarios")
                if (sa != null) {
                    for (k in 0 until sa.length()) {
                        val so = sa.optJSONObject(k) ?: continue
                        val scenario = scenarioFromJson(so)
                        if (scenario.word.isNotBlank()) b.ocrScenarios.add(scenario)
                    }
                }
                buttons.add(b)
            }
            add(Pattern(po.optString("name", "Шаблон 1"), po.optBoolean("enabled", true), buttons))
        }
    }

    fun loadPatterns(ctx: Context): MutableList<Pattern> {
        val raw = prefs(ctx).getString(KEY_PATTERNS, null)
        if (raw == null) return mutableListOf(Pattern("Шаблон 1")).also { savePatterns(ctx, it) }
        return try { patternsFromJson(JSONArray(raw)).ifEmpty { mutableListOf(Pattern("Шаблон 1")) } } catch (_: Exception) { mutableListOf(Pattern("Шаблон 1")) }
    }

    fun savePatterns(ctx: Context, patterns: List<Pattern>) = prefs(ctx).edit().putString(KEY_PATTERNS, patternsToJson(patterns).toString()).apply()

    fun findButton(ctx: Context, id: String): Pair<Pattern, NamedButton>? = loadPatterns(ctx).firstNotNullOfOrNull { p -> p.buttons.find { it.id == id }?.let { p to it } }
    fun allButtonsFlat(ctx: Context): List<Pair<Pattern, NamedButton>> = loadPatterns(ctx).flatMap { p -> p.buttons.map { p to it } }

    fun getButtonEnabled(ctx: Context) = prefs(ctx).getBoolean(KEY_BUTTON_ENABLED, true)
    fun setButtonEnabled(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean(KEY_BUTTON_ENABLED, v).apply()
    fun getAdderEnabled(ctx: Context) = prefs(ctx).getBoolean(KEY_ADDER_ENABLED, true)
    fun setAdderEnabled(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean(KEY_ADDER_ENABLED, v).apply()
    fun getShowResizeHandle(ctx: Context) = prefs(ctx).getBoolean(KEY_SHOW_RESIZE, false)
    fun setShowResizeHandle(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean(KEY_SHOW_RESIZE, v).apply()
    fun getAdderX(ctx: Context) = prefs(ctx).getInt(KEY_ADDER_X, -1)
    fun getAdderY(ctx: Context) = prefs(ctx).getInt(KEY_ADDER_Y, -1)
    fun setAdderPosition(ctx: Context, x: Int, y: Int) = prefs(ctx).edit().putInt(KEY_ADDER_X, x).putInt(KEY_ADDER_Y, y).apply()

    fun typeLabel(type: StepType) = when (type) {
        StepType.TAP -> "Нажатие"; StepType.DOUBLE_TAP -> "Двойное нажатие"; StepType.TRIPLE_TAP -> "Тройное нажатие"
        StepType.LONG_PRESS -> "Зажатие"; StepType.WAIT -> "Ожидание"; StepType.FIND_WORD -> "Найти другое слово"; StepType.OPEN_APP -> "Открыть приложение"
    }
    fun typeIcon(type: StepType) = when (type) { StepType.TAP -> "👆"; StepType.DOUBLE_TAP -> "2×"; StepType.TRIPLE_TAP -> "3×"; StepType.LONG_PRESS -> "⏱"; StepType.WAIT -> "⏳"; StepType.FIND_WORD -> "🔎"; StepType.OPEN_APP -> "📱" }
    fun vibeLabel(style: VibeStyle) = when (style) { VibeStyle.SHORT -> "Коротко"; VibeStyle.MEDIUM -> "Средне"; VibeStyle.LONG -> "Длинно"; VibeStyle.DOUBLE -> "Дважды" }
    fun shapeIcon(shape: ButtonShape) = when (shape) { ButtonShape.CIRCLE -> "●"; ButtonShape.SQUARE -> "■"; ButtonShape.ROUNDED_SQUARE -> "▢"; ButtonShape.STAR -> "★" }

    fun exportToJson(ctx: Context): String = JSONObject().apply {
        put("app", "TapBot"); put("formatVersion", EXPORT_FORMAT_VERSION); put("patterns", patternsToJson(loadPatterns(ctx)))
    }.toString(2)

    fun importFromJson(ctx: Context, text: String): Int = try {
        val root = JSONObject(text); val arr = root.optJSONArray("patterns") ?: return -1
        val imported = patternsFromJson(arr); if (imported.isEmpty()) return -1
        val current = loadPatterns(ctx); val names = current.map { it.name }.toMutableSet()
        imported.forEach { p -> var n = p.name; while (!names.add(n)) n += " (импорт)"; p.name = n; current.add(p) }
        savePatterns(ctx, current); imported.size
    } catch (_: Exception) { -1 }

    /** One-time migration of old global OCR bindings into the new per-button model. */
    fun migrateOldOcrRules(ctx: Context) {
        val prefs = prefs(ctx)
        val raw = prefs.getString("ocr_rules_json", null) ?: return
        try {
            val rules = JSONArray(raw); val patterns = loadPatterns(ctx)
            var changed = false
            for (i in 0 until rules.length()) {
                val r = rules.optJSONObject(i) ?: continue
                val word = r.optString("searchText", "").trim(); val id = r.optString("targetButtonId", "")
                if (word.isBlank() || id.isBlank()) continue
                val b = patterns.flatMap { it.buttons }.find { it.id == id } ?: continue
                if (b.ocrScenarios.none { it.word.equals(word, true) }) {
                    val actions = if (b.actions.isNotEmpty()) b.actions.map { it.copy(coordinateSource = CoordinateSource.OCR) }.toMutableList() else mutableListOf()
                    b.ocrScenarios.add(OcrScenario(word = word, actions = actions)); changed = true
                }
                b.enabled = true
            }
            if (changed) savePatterns(ctx, patterns)
        } catch (_: Exception) {}
        prefs.edit().remove("ocr_rules_json").remove("ocr_enabled").remove("ocr_cooldown_ms").remove("ocr_region_left").remove("ocr_region_top").remove("ocr_region_right").remove("ocr_region_bottom").apply()
    }
}
