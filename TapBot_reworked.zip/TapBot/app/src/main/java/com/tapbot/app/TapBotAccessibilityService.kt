package com.tapbot.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.UUID

class TapBotAccessibilityService : AccessibilityService() {
    companion object { var instance: TapBotAccessibilityService? = null }

    private var wm: WindowManager? = null
    private val handler = Handler(Looper.getMainLooper())
    private val buttonViews = mutableMapOf<String, View>()
    private var adderView: View? = null
    private var menuView: View? = null
    private var settingsOpen = false
    private var running = false

    private var pendingPattern: String? = null
    private var pendingButtonId: String? = null
    private var pendingButtonName: String? = null
    private var pendingOcr = false
    private var pendingWord: String? = null
    private var pendingActions = mutableListOf<ButtonAction>()
    private var pendingOcrScenarios = mutableListOf<OcrScenario>()
    private var editingActionIndex: Int? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        PatternStore.migrateOldOcrRules(this)
        refreshButtonVisibility()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
        removeMenu(); removeButtons(); removeAdder()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {}
    override fun onInterrupt() {}

    fun setSettingsScreenActive(active: Boolean) {
        settingsOpen = active
        if (active) { removeButtons(); removeAdder() } else refreshButtonVisibility()
    }

    fun refreshButtonVisibility() {
        removeButtons(); removeAdder()
        if (settingsOpen || !PatternStore.getButtonEnabled(this)) return
        val patterns = PatternStore.loadPatterns(this)
        patterns.filter { it.enabled }.flatMap { it.buttons }.filter { it.enabled }.forEach { addButton(it) }
        addAdder()
    }

    private fun overlayFlags(): Int = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

    private fun buttonBg(color: Int, shape: ButtonShape): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        when (shape) {
            ButtonShape.CIRCLE -> shape = GradientDrawable.OVAL
            ButtonShape.SQUARE -> { shape = GradientDrawable.RECTANGLE; cornerRadius = 0f }
            ButtonShape.ROUNDED_SQUARE -> { shape = GradientDrawable.RECTANGLE; cornerRadius = 18f }
            ButtonShape.STAR -> { shape = GradientDrawable.OVAL } // simple/fast fallback
        }
    }

    private fun addButton(b: NamedButton) {
        val manager = wm ?: return
        val density = resources.displayMetrics.density
        val root = FrameLayout(this)
        val stack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val size = (b.sizeDp * density).toInt()
        val face = View(this).apply { tag = "face"; background = buttonBg(b.color, b.shape) }
        stack.addView(face, LinearLayout.LayoutParams(size, size))
        stack.addView(TextView(this).apply {
            text = b.name; textSize = 11f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(10, 4, 10, 4)
            background = GradientDrawable().apply { setColor(0xB0000000.toInt()); cornerRadius = 8f }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(stack)


        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, overlayFlags(), PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = safeX(b.btnX, size)
            y = safeY(b.btnY, size)
        }

        if(PatternStore.getShowResizeHandle(this)){
            val handle=View(this).apply{background=GradientDrawable().apply{setColor(0xEEFFFFFF.toInt());cornerRadius=5f}}
            root.addView(handle,FrameLayout.LayoutParams((16*density).toInt(),(16*density).toInt()).apply{leftMargin=size-8;topMargin=size-8})
            var start=0;var startX=0f;var startY=0f
            handle.setOnTouchListener{_,e->when(e.actionMasked){MotionEvent.ACTION_DOWN->{start=b.sizeDp;startX=e.rawX;startY=e.rawY;true};MotionEvent.ACTION_MOVE->{val delta=((e.rawX-startX)+(e.rawY-startY))/2f/density;val ns=(start+delta.toInt()).coerceIn(32,140);b.sizeDp=ns;val np=handle.layoutParams as FrameLayout.LayoutParams;np.leftMargin=(ns*density).toInt()-8;np.topMargin=(ns*density).toInt()-8;handle.layoutParams=np;face.layoutParams=face.layoutParams.apply{width=(ns*density).toInt();height=(ns*density).toInt()};root.requestLayout();try{manager.updateViewLayout(root,params)}catch(_:Exception){};true};MotionEvent.ACTION_UP->{val data=PatternStore.loadPatterns(this);data.flatMap{it.buttons}.find{it.id==b.id}?.sizeDp=b.sizeDp;PatternStore.savePatterns(this,data);refreshButtonVisibility();true};else->true}}
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        val longMs = ViewConfiguration.getLongPressTimeout().toLong()
        var sx = 0f; var sy = 0f; var px = params.x; var py = params.y; var moved = false; var longDone = false; var taps = 0
        val longRun = Runnable { if (!moved) { longDone = true; taps = 0; showButtonMenu(b.id) } }
        val tapRun = Runnable { if (taps == b.triggerTaps.coerceIn(1, 3)) triggerButton(b.id) ; taps = 0 }

        root.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; px=params.x; py=params.y; moved=false; longDone=false; handler.postDelayed(longRun,longMs); true }
                MotionEvent.ACTION_MOVE -> {
                    val dx=e.rawX-sx; val dy=e.rawY-sy
                    if (!moved && (kotlin.math.abs(dx)>slop || kotlin.math.abs(dy)>slop)) { moved=true; handler.removeCallbacks(longRun) }
                    if (moved) { params.x=safeX(px+dx.toInt(), root.width); params.y=safeY(py+dy.toInt(), root.height); try { manager.updateViewLayout(root,params) } catch (_:Exception){} }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longRun)
                    if (moved) {
                        saveButtonPosition(b.id, params.x, params.y)
                    } else if (!longDone) {
                        handler.removeCallbacks(tapRun); taps++; handler.postDelayed(tapRun, 320L)
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> { handler.removeCallbacks(longRun); true }
                else -> false
            }
        }
        try { manager.addView(root, params); buttonViews[b.id] = root } catch (_: Exception) {}
    }

    private fun safeX(value: Int, width: Int): Int {
        val sw = resources.displayMetrics.widthPixels
        return if (value < 0) 40 else value.coerceIn(0, (sw - width.coerceAtLeast(1)).coerceAtLeast(0))
    }
    private fun safeY(value: Int, height: Int): Int {
        val sh = resources.displayMetrics.heightPixels
        return if (value < 0) 300 else value.coerceIn(0, (sh - height.coerceAtLeast(1)).coerceAtLeast(0))
    }

    private fun saveButtonPosition(id: String, x: Int, y: Int) {
        val list = PatternStore.loadPatterns(this)
        list.flatMap { it.buttons }.find { it.id == id }?.apply { btnX=x; btnY=y }
        PatternStore.savePatterns(this,list)
    }

    private fun removeButtons() { val manager=wm ?: return; buttonViews.values.forEach { try { manager.removeView(it) } catch (_:Exception){} }; buttonViews.clear() }
    private fun removeAdder() { adderView?.let { try { wm?.removeView(it) } catch (_:Exception){} }; adderView=null }

    private fun addAdder() {
        val manager=wm ?: return
        if (!PatternStore.getAdderEnabled(this)) return
        val d=resources.displayMetrics.density; val size=(46*d).toInt()
        val v=TextView(this).apply { text="+"; textSize=22f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(0xDD252525.toInt())} }
        val p=WindowManager.LayoutParams(size,size,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,overlayFlags(),PixelFormat.TRANSLUCENT).apply{
            gravity=Gravity.TOP or Gravity.START; x=safeX(PatternStore.getAdderX(this@TapBotAccessibilityService),size); y=safeY(PatternStore.getAdderY(this@TapBotAccessibilityService),size)
        }
        val slop=ViewConfiguration.get(this).scaledTouchSlop; var sx=0f;var sy=0f;var px=0;var py=0;var moved=false
        v.setOnTouchListener { _,e -> when(e.actionMasked){
            MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;px=p.x;py=p.y;moved=false;true}
            MotionEvent.ACTION_MOVE->{val dx=e.rawX-sx;val dy=e.rawY-sy;if(!moved&&(kotlin.math.abs(dx)>slop||kotlin.math.abs(dy)>slop))moved=true;if(moved){p.x=safeX(px+dx.toInt(),size);p.y=safeY(py+dy.toInt(),size);try{manager.updateViewLayout(v,p)}catch(_:Exception){}};true}
            MotionEvent.ACTION_UP->{if(moved)PatternStore.setAdderPosition(this,p.x,p.y) else startCreate();true}
            else->true
        }}
        try{manager.addView(v,p);adderView=v}catch(_:Exception){}
    }

    private fun startCreate() {
        val patterns=PatternStore.loadPatterns(this)
        if(patterns.size==1) startCreateFor(patterns[0].name) else showPatternPicker(patterns)
    }
    fun startCreateFor(pattern: String) {
        pendingPattern=pattern;pendingButtonId=null;pendingButtonName=null;pendingOcr=false;pendingWord=null;pendingActions.clear();pendingOcrScenarios.clear();editingActionIndex=null
        showCreationMode()
    }

    private fun showCreationMode() {
        val box=menuBox()
        box.addView(title("Новая кнопка"))
        box.addView(menuButton("👆 Нажать в нужное место",true){
            pendingOcr=false
            askText("Название кнопки","Например: Заказы") { pendingButtonName=it; showTypeMenu() }
        }.margin(0))
        box.addView(menuButton("🔎 Автопоиск слова",true){
            pendingOcr=true
            askText("Название кнопки","Например: Заказы") { pendingButtonName=it; showOcrWordMenu() }
        }.margin())
        box.addView(menuButton("Отмена"){cancelPending()}.margin(14))
        showMenu(box)
    }

    private fun showOcrWordMenu() {
        val box=menuBox();box.addView(title("Слово для поиска"))
        box.addView(TextView(this).apply{ text="Добавьте первое слово, затем его действия. Потом можно добавить ещё слова.";textSize=13f;setTextColor(0xFFBBBBBB.toInt());setPadding(4,0,4,12) })
        box.addView(menuButton("+ Добавить слово",true){ askText("Какое слово искать?","Например: Продолжить"){ pendingWord=it;pendingActions=mutableListOf();showTypeMenu() } }.margin(0))
        box.addView(menuButton("Готово"){ if(pendingButtonId!=null){finishOcrCreation()}else Toast.makeText(this,"Добавьте хотя бы одно слово",Toast.LENGTH_SHORT).show() }.margin(12))
        box.addView(menuButton("Отмена"){cancelPending()}.margin())
        showMenu(box)
    }

    private fun finishOcrCreation(){ pendingPattern=null;pendingButtonId=null;pendingButtonName=null;pendingOcr=false;pendingWord=null;pendingActions.clear();pendingOcrScenarios.clear();removeMenu();refreshButtonVisibility() }

    private fun showPatternPicker(patterns: List<Pattern>) {
        val box=menuBox();box.addView(title("Куда добавить кнопку?"))
        patterns.forEach { p -> box.addView(menuButton(p.name,true){startCreateFor(p.name)}.margin()) }
        box.addView(menuButton("Отмена"){removeMenu()}.margin())
        showMenu(box)
    }

    private fun askText(caption:String,hint:String,onDone:(String)->Unit){
        val manager=wm ?: return; removeMenuOnly()
        val box=menuBox();box.addView(title(caption));
        val input=EditText(this).apply{setTextColor(Color.WHITE);setHintTextColor(0xFF999999.toInt());this.hint=hint;inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;setSingleLine();isFocusable=true;isFocusableInTouchMode=true}
        box.addView(input.margin(0));box.addView(menuButton("Далее",true){val s=input.text.toString().trim();if(s.isBlank())Toast.makeText(this,"Введите текст",Toast.LENGTH_SHORT).show()else{hideKeyboard(input);removeMenu();onDone(s)}}.margin(12));box.addView(menuButton("Отмена"){cancelPending()}.margin())
        val type=if(Settings.canDrawOverlays(this))WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        val p=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,0,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.CENTER;softInputMode=WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE}
        try{manager.addView(box,p);menuView=box}catch(_:Exception){return}
        input.requestFocus()
        val imm=getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        input.setOnClickListener{input.requestFocus();imm?.showSoftInput(input,InputMethodManager.SHOW_FORCED)}
        handler.postDelayed({imm?.showSoftInput(input,InputMethodManager.SHOW_FORCED)},150)
        handler.postDelayed({imm?.showSoftInput(input,InputMethodManager.SHOW_FORCED)},450)
        handler.postDelayed({imm?.showSoftInput(input,InputMethodManager.SHOW_FORCED)},800)
    }
    private fun hideKeyboard(v:View){(getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)?.hideSoftInputFromWindow(v.windowToken,0)}

    private fun showTypeMenu(){
        val box=menuBox();box.addView(title(if(pendingOcr) "Действие для слова «${pendingWord ?: ""}»" else "Добавить действие"))
        box.addView(menuButton("👆 Нажатие",true){chooseTap(StepType.TAP)}.margin(0))
        box.addView(menuButton("2× Двойное нажатие",true){chooseTap(StepType.DOUBLE_TAP)}.margin())
        box.addView(menuButton("3× Тройное нажатие",true){chooseTap(StepType.TRIPLE_TAP)}.margin())
        box.addView(menuButton("⏱ Зажатие",true){chooseDuration(true)}.margin())
        box.addView(menuButton("⏳ Ожидание",true){chooseDuration(false)}.margin())
        box.addView(menuButton("🔎 Найти другое слово",true){if(!pendingOcr){Toast.makeText(this,"Доступно только для автопоиска",Toast.LENGTH_SHORT).show()}else askText("Новое слово","Например: Готово"){pendingWordForAction=it; addFinishedAction(ButtonAction(type=StepType.FIND_WORD,searchWord=it,coordinateSource=CoordinateSource.OCR))}}.margin())
        box.addView(menuButton("📱 Открыть приложение",true){showAppPicker()}.margin())
        box.addView(menuButton("Отмена"){cancelPending()}.margin(14));showMenu(box)
    }
    private var pendingWordForAction:String?=null

    private fun chooseTap(type:StepType){ if(pendingOcr)addFinishedAction(ButtonAction(type=type,coordinateSource=CoordinateSource.OCR)) else showLocationPicker(type,50L) }
    private fun chooseDuration(longPress:Boolean){
        var ms=1000L;val box=menuBox();box.addView(title(if(longPress)"Зажатие" else "Ожидание"));val label=TextView(this).apply{setTextColor(Color.WHITE);textSize=26f;gravity=Gravity.CENTER};box.addView(label.margin(0));
        fun refresh(){label.text=String.format("%.1f с",ms/1000.0)};refresh()
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};row.addView(menuButton("−1с"){ms=(ms-1000).coerceAtLeast(100);refresh()}.weight());row.addView(menuButton("−0,1с"){ms=(ms-100).coerceAtLeast(100);refresh()}.weight());row.addView(menuButton("+0,1с"){ms=(ms+100).coerceAtMost(60000);refresh()}.weight());row.addView(menuButton("+1с"){ms=(ms+1000).coerceAtMost(60000);refresh()}.weight());box.addView(row.margin(10));box.addView(menuButton(if(longPress)"Далее" else "Добавить",true){addFinishedAction(if(longPress)ButtonAction(type=StepType.LONG_PRESS,longPressMs=ms,coordinateSource=if(pendingOcr)CoordinateSource.OCR else CoordinateSource.FIXED)else ButtonAction(type=StepType.WAIT,waitMs=ms))}.margin(14));box.addView(menuButton("Отмена"){cancelPending()}.margin());showMenu(box)
    }

    private fun showLocationPicker(type:StepType,duration:Long){
        val manager=wm?:return;removeMenu();val root=FrameLayout(this).apply{setBackgroundColor(0x22000000)}
        val info=TextView(this).apply{text="Коснитесь места, куда должна нажимать кнопка\n${PatternStore.typeLabel(type)}";textSize=15f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=cardBg();setPadding(28,20,28,20)}
        root.addView(info,FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,FrameLayout.LayoutParams.WRAP_CONTENT,Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply{topMargin=70})
        val p=WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,overlayFlags(),PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START}
        root.setOnTouchListener{_,e->if(e.actionMasked==MotionEvent.ACTION_UP){addFinishedAction(ButtonAction(type=type,x=e.rawX.toInt(),y=e.rawY.toInt(),longPressMs=duration,coordinateSource=CoordinateSource.FIXED));true}else true}
        try{manager.addView(root,p);menuView=root}catch(_:Exception){}
    }

    private fun addFinishedAction(action:ButtonAction){
        val edit=pendingButtonId
        if(edit!=null){ val data=PatternStore.loadPatterns(this);val b=data.flatMap{it.buttons}.find{it.id==edit}?:return;val idx=editingActionIndex;if(idx!=null&&idx in b.actions.indices)b.actions[idx]=action else b.actions.add(action);PatternStore.savePatterns(this,data);editingActionIndex=null;showActions(edit);return }
        pendingActions.add(action)
        if(pendingOcr) showAfterActionOcr() else showAfterActionManual()
    }

    private fun showAfterActionManual(){val box=menuBox();box.addView(title("Действие добавлено"));box.addView(menuButton("+ Ещё действие",true){showTypeMenu()}.margin(0));box.addView(menuButton("Готово — создать кнопку",true){finishManual()}.margin(12));box.addView(menuButton("Отмена"){cancelPending()}.margin());showMenu(box)}
    private fun finishManual(){
        val name=pendingButtonName?:return
        val data=PatternStore.loadPatterns(this)
        val p=data.find{it.name==pendingPattern}?:data.first()
        val firstPoint=pendingActions.firstOrNull{it.type==StepType.TAP||it.type==StepType.DOUBLE_TAP||it.type==StepType.TRIPLE_TAP||it.type==StepType.LONG_PRESS}
        val b=NamedButton(UUID.randomUUID().toString(),name,btnX=firstPoint?.let{it.x-28}?:-1,btnY=firstPoint?.let{it.y-28}?:-1,actions=pendingActions.toMutableList())
        p.buttons.add(b)
        PatternStore.savePatterns(this,data)
        cancelPending();refreshButtonVisibility();Toast.makeText(this,"Кнопка «$name» создана",Toast.LENGTH_SHORT).show()
    }

    private fun showAfterActionOcr(){
        val box=menuBox()
        box.addView(title("Действие для «${pendingWord ?: ""}» добавлено"))
        box.addView(menuButton("+ Ещё действие",true){showTypeMenu()}.margin(0))
        box.addView(menuButton("Готово — сохранить слово",true){finishOcrWord()}.margin(12))
        box.addView(menuButton("Отмена"){cancelPending()}.margin())
        showMenu(box)
    }

    private fun finishOcrWord(){
        val word=pendingWord ?: return
        val scenarioActions=pendingActions.map { action ->
            if(action.type==StepType.FIND_WORD || action.type==StepType.WAIT || action.type==StepType.OPEN_APP) action.copy()
            else action.copy(coordinateSource=CoordinateSource.OCR)
        }.toMutableList()
        val scenario=OcrScenario(word=word,actions=scenarioActions)
        val data=PatternStore.loadPatterns(this)
        val pattern=data.find{it.name==pendingPattern} ?: data.first()
        val button:NamedButton
        if(pendingButtonId==null){
            button=NamedButton(UUID.randomUUID().toString(),pendingButtonName ?: "Авто",enabled=true)
            pattern.buttons.add(button)
            pendingButtonId=button.id
        }else{
            button=pattern.buttons.find{it.id==pendingButtonId} ?: return
        }
        button.ocrScenarios.add(scenario)
        PatternStore.savePatterns(this,data)
        pendingActions=mutableListOf();pendingWord=null
        refreshButtonVisibility();showOcrWordMenu()
    }

    private fun triggerButton(id:String){
        val owner=PatternStore.findButton(this,id)?:return;val b=owner.second
        if(b.ocrScenarios.isNotEmpty()) runOcrButton(b) else runScenario(b,b.actions.toList(),null)
    }

    /** One scan per button press. There is intentionally no background OCR loop. */
    private fun runOcrButton(b:NamedButton){
        if(running)return;running=true
        findTextOnce(b.ocrScenarios.filter{it.enabled}.map{it.word}){matchWord,point->
            if(matchWord==null||point==null){running=false;Toast.makeText(this,"Слово не найдено",Toast.LENGTH_SHORT).show();return@findTextOnce}
            val s=b.ocrScenarios.firstOrNull{it.enabled&&it.word.equals(matchWord,true)}
            if(s==null){running=false;return@findTextOnce}
            runScenario(b,s.actions.toList(),point){running=false}
        }
    }

    /** Fast path: Accessibility tree. If the current app exposes text nodes, no screenshot/OCR is needed. */
    private fun findInAccessibility(words:List<String>):Pair<String,android.graphics.Point>?{
        val root=rootInActiveWindow?:return null
        val wanted=words.filter{it.isNotBlank()}.sortedByDescending{it.length}
        var best:Triple<String,android.graphics.Point,Long>?=null
        fun walk(n:AccessibilityNodeInfo?){
            if(n==null)return
            val text=(n.text?.toString()?:n.contentDescription?.toString()?:"").trim()
            if(text.isNotBlank()){
                for(word in wanted){
                    if(text.contains(word,true)){
                        val r=Rect();n.getBoundsInScreen(r)
                        if(!r.isEmpty){
                            val area=r.width().toLong()*r.height().toLong()
                            val exact=if(text.equals(word,true))0L else 1L
                            val score=area*10L+exact
                            if(best==null||score<best!!.third) best=Triple(word,android.graphics.Point(r.centerX(),r.centerY()),score)
                        }
                    }
                }
            }
            for(i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return best?.let{it.first to it.second}
    }

    private fun findTextOnce(words:List<String>,done:(String?,android.graphics.Point?)->Unit){
        val fast=findInAccessibility(words);if(fast!=null){done(fast.first,fast.second);return}
        if(Build.VERSION.SDK_INT<Build.VERSION_CODES.R){done(null,null);return}
        captureScreen{bmp->if(bmp==null){done(null,null);return@captureScreen}
            val recognizer=com.google.mlkit.vision.text.TextRecognition.getClient(com.google.mlkit.vision.text.cyrillic.CyrillicTextRecognizerOptions.Builder().build())
            val image=com.google.mlkit.vision.common.InputImage.fromBitmap(bmp,0)
            recognizer.process(image).addOnSuccessListener{res->
                var hit:Pair<String,android.graphics.Point>?=null
                outer@for(w in words){for(block in res.textBlocks)for(line in block.lines){val t=line.text;if(t.contains(w,true)){val r=line.boundingBox;if(r!=null){hit=w to android.graphics.Point(r.centerX(),r.centerY());break@outer}}}}
                try{bmp.recycle()}catch(_:Exception){};recognizer.close();done(hit?.first,hit?.second)
            }.addOnFailureListener{try{bmp.recycle()}catch(_:Exception){};recognizer.close();done(null,null)}
        }
    }

    private fun captureScreen(done:(android.graphics.Bitmap?)->Unit){
        if(Build.VERSION.SDK_INT<Build.VERSION_CODES.R){done(null);return}
        try{takeScreenshot(android.view.Display.DEFAULT_DISPLAY,mainExecutor,object:TakeScreenshotCallback{
            override fun onSuccess(result:ScreenshotResult){val b=try{val h=android.graphics.Bitmap.wrapHardwareBuffer(result.hardwareBuffer,result.colorSpace);val s=h?.copy(android.graphics.Bitmap.Config.ARGB_8888,false);result.hardwareBuffer.close();s}catch(_:Exception){null};done(b)}
            override fun onFailure(errorCode:Int){done(null)}
        })}catch(_:Exception){done(null)}
    }

    private fun runScenario(b:NamedButton,actions:List<ButtonAction>,start:android.graphics.Point?,done:()->Unit={}){
        runActions(b,actions,0,RunToken(),start,done)
    }
    private class RunToken{var cancelled=false}
    private fun runActions(b:NamedButton,actions:List<ButtonAction>,i:Int,token:RunToken,point:android.graphics.Point?,done:()->Unit){
        if(token.cancelled||i>=actions.size){done();return};val a=actions[i]
        fun next(p:android.graphics.Point?=point,delay:Long=100L){handler.postDelayed({runActions(b,actions,i+1,token,p,done)},delay)}
        when(a.type){
            StepType.WAIT->handler.postDelayed({next(point,0)},a.waitMs.coerceIn(100,60000))
            StepType.OPEN_APP->{a.appPackage?.let{packageManager.getLaunchIntentForPackage(it)?.also{inr->inr.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);try{startActivity(inr)}catch(_:Exception){}}};next(point,300)}
            StepType.FIND_WORD->{findTextOnce(listOf(a.searchWord)){_,p->if(p==null){Toast.makeText(this,"Слово «${a.searchWord}» не найдено",Toast.LENGTH_SHORT).show();next(point)}else next(p)}}
            else->{val p=if(a.coordinateSource==CoordinateSource.OCR)point else android.graphics.Point(a.x,a.y);if(p==null){next(point);return};dispatchGestureAt(p.x,p.y,a){next(p,0)}}
        }
    }
    private fun dispatchGestureAt(x:Int,y:Int,a:ButtonAction,done:()->Unit){
        val taps=when(a.type){StepType.TAP->1;StepType.DOUBLE_TAP->2;StepType.TRIPLE_TAP->3;else->1};var count=0
        fun one(){if(count>=taps){done();return};val path=Path().apply{moveTo(x.toFloat(),y.toFloat())};val dur=if(a.type==StepType.LONG_PRESS)a.longPressMs.coerceIn(100,60000)else 50L;val g=GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,dur)).build();if(!dispatchGesture(g,object:GestureResultCallback(){override fun onCompleted(gd:GestureDescription?){count++;handler.postDelayed({one()},if(taps>1)80 else 0)}override fun onCancelled(gd:GestureDescription?){count++;handler.postDelayed({one()},80)}},null)){done()}}
        one()
    }

    fun openButtonForSettings(id:String){ showButtonMenu(id) }

    private fun showButtonMenu(id:String){val owner=PatternStore.findButton(this,id)?:return;val b=owner.second;val box=menuBox();box.addView(title("Кнопка «${b.name}»"));box.addView(menuButton("Действия (${b.actions.size})",true){showActions(id)}.margin(0));if(b.ocrScenarios.isNotEmpty())box.addView(menuButton("Слова (${b.ocrScenarios.size})",true){showWords(id)}.margin());box.addView(menuButton(if(b.enabled)"Выключить кнопку" else "Включить кнопку"){saveButton(id){it.enabled=!it.enabled};removeMenu();refreshButtonVisibility()}.margin());box.addView(menuButton("Переименовать"){askText("Название кнопки",b.name){n->saveButton(id){it.name=n};removeMenu();refreshButtonVisibility()}}.margin());box.addView(menuButton("Размер: ${b.sizeDp} dp"){showSize(id)}.margin());box.addView(menuButton("Цвет"){showColors(id)}.margin());box.addView(menuButton("Удалить кнопку"){confirmDelete(id)}.margin(14));box.addView(menuButton("Закрыть"){removeMenu()}.margin());showMenu(box)}

    private fun showWords(id:String){val b=PatternStore.findButton(this,id)?.second?:return;val box=menuBox();box.addView(title("Слова кнопки"));b.ocrScenarios.forEachIndexed{i,s->val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL};row.addView(TextView(this).apply{text="${i+1}. ${s.word} (${s.actions.size})";setTextColor(Color.WHITE);textSize=14f;layoutParams=LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f)});row.addView(menuButton("🗑"){val data=PatternStore.loadPatterns(this);data.flatMap{it.buttons}.find{it.id==id}?.ocrScenarios?.removeAt(i);PatternStore.savePatterns(this,data);showWords(id)}.margin(0));box.addView(row.margin(8))};box.addView(menuButton("+ Добавить слово"){pendingButtonId=id;pendingOcr=true;pendingPattern=PatternStore.findButton(this,id)?.first?.name;askText("Какое слово искать?","Например: Готово"){pendingWord=it;pendingActions=mutableListOf();showTypeMenu()}}.margin(12));box.addView(menuButton("Закрыть"){removeMenu()}.margin());showMenu(box)}

    private fun showActions(id:String){val b=PatternStore.findButton(this,id)?.second?:return;val box=menuBox();box.addView(title("Действия «${b.name}»"));b.actions.forEachIndexed{i,a->val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL};row.addView(TextView(this).apply{text="${i+1}. ${PatternStore.typeLabel(a.type)}"+when(a.type){StepType.LONG_PRESS->String.format(" %.1fс",a.longPressMs/1000.0);StepType.WAIT->String.format(" %.1fс",a.waitMs/1000.0);StepType.OPEN_APP->" ${a.appLabel?:""}";StepType.FIND_WORD->" «${a.searchWord}";else->""};setTextColor(Color.WHITE);textSize=13f;layoutParams=LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f)});row.addView(menuButton("↑"){moveAction(id,i,-1)}.margin(0));row.addView(menuButton("↓"){moveAction(id,i,1)}.margin(0));row.addView(menuButton("🗑"){deleteAction(id,i)}.margin(0));box.addView(row.margin(7))};box.addView(menuButton("+ Добавить действие",true){pendingButtonId=id;pendingOcr=b.ocrScenarios.isNotEmpty();pendingPattern=PatternStore.findButton(this,id)?.first?.name;pendingActions=mutableListOf();showTypeMenu()}.margin(14));box.addView(menuButton("Закрыть"){removeMenu()}.margin());showMenu(box)}

    private fun moveAction(id:String,i:Int,d:Int){val data=PatternStore.loadPatterns(this);val b=data.flatMap{it.buttons}.find{it.id==id}?:return;val n=i+d;if(n in b.actions.indices){val x=b.actions.removeAt(i);b.actions.add(n,x);PatternStore.savePatterns(this,data)};showActions(id)}
    private fun deleteAction(id:String,i:Int){val data=PatternStore.loadPatterns(this);data.flatMap{it.buttons}.find{it.id==id}?.actions?.removeAt(i);PatternStore.savePatterns(this,data);showActions(id)}
    private fun saveButton(id:String,change:(NamedButton)->Unit){val data=PatternStore.loadPatterns(this);data.flatMap{it.buttons}.find{it.id==id}?.let{change(it)};PatternStore.savePatterns(this,data)}
    private fun confirmDelete(id:String){val box=menuBox();box.addView(title("Удалить кнопку?"));box.addView(menuButton("Удалить",true){val data=PatternStore.loadPatterns(this);data.forEach{it.buttons.removeAll{b->b.id==id}};PatternStore.savePatterns(this,data);removeMenu();refreshButtonVisibility()}.margin(0));box.addView(menuButton("Отмена"){removeMenu()}.margin());showMenu(box)}

    private fun showSize(id:String){var size=PatternStore.findButton(this,id)?.second?.sizeDp?:56;val box=menuBox();box.addView(title("Размер"));val v=TextView(this).apply{setTextColor(Color.WHITE);textSize=24f;gravity=Gravity.CENTER};box.addView(v);fun r(){v.text="$size dp"};r();val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};row.addView(menuButton("−4"){size=(size-4).coerceIn(32,140);r()}.weight());row.addView(menuButton("+4"){size=(size+4).coerceIn(32,140);r()}.weight());box.addView(row.margin(10));box.addView(menuButton("Готово",true){saveButton(id){it.sizeDp=size};removeMenu();refreshButtonVisibility()}.margin(14));box.addView(menuButton("Отмена"){removeMenu()}.margin());showMenu(box)}
    private fun showColors(id:String){val box=menuBox();box.addView(title("Цвет кнопки"));val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};PatternStore.COLOR_PALETTE.forEach{c->row.addView(View(this).apply{background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(c)};setOnClickListener{saveButton(id){it.color=c};removeMenu();refreshButtonVisibility()};layoutParams=LinearLayout.LayoutParams(42,42).apply{marginEnd=8}})};box.addView(row);box.addView(menuButton("Закрыть"){removeMenu()}.margin(14));showMenu(box)}

    private fun showAppPicker(){val pm=packageManager;val apps=pm.getInstalledApplications(0).filter{pm.getLaunchIntentForPackage(it.packageName)!=null}.sortedBy{pm.getApplicationLabel(it).toString().lowercase()};val box=menuBox();box.addView(title("Открыть приложение"));val scroll=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};apps.forEach{app->val label=pm.getApplicationLabel(app).toString();list.addView(menuButton(label){addFinishedAction(ButtonAction(type=StepType.OPEN_APP,appPackage=app.packageName,appLabel=label))}.margin(4))};scroll.addView(list);box.addView(scroll,LinearLayout.LayoutParams(520,700));box.addView(menuButton("Отмена"){cancelPending()}.margin());showMenu(box)}

    private fun menuBox()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=cardBg();setPadding(24,24,24,24)}
    private fun cardBg()=GradientDrawable().apply{setColor(0xF01C1C1C.toInt());cornerRadius=26f}
    private fun title(s:String)=TextView(this).apply{text=s;textSize=19f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.WHITE);setPadding(4,0,4,14)}
    private fun menuButton(s:String,big:Boolean=false,onClick:()->Unit)=TextView(this).apply{text=s;textSize=if(big)16f else 14f;setTextColor(Color.WHITE);setGravity(Gravity.CENTER_VERTICAL);setPadding(20,16,20,16);background=GradientDrawable().apply{setColor(0x332F2F2F.toInt());cornerRadius=14f};setOnClickListener{onClick()}}
    private fun View.margin(top:Int=8):View{layoutParams=LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT).apply{this.topMargin=top};return this}
    private fun View.weight():View{layoutParams=LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f).apply{marginStart=3;marginEnd=3};return this}

    private fun showMenu(view:View){
        val manager=wm?:return
        menuView?.let{try{manager.removeView(it)}catch(_:Exception){}}
        menuView=null
        removeButtons();removeAdder()
        val type=WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        val p=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.CENTER}
        try{manager.addView(view,p);menuView=view}catch(_:Exception){}
    }
    private fun removeMenuOnly(){menuView?.let{try{wm?.removeView(it)}catch(_:Exception){}};menuView=null}
    private fun removeMenu(){
        menuView?.let{try{wm?.removeView(it)}catch(_:Exception){}}
        menuView=null
        if(!settingsOpen)refreshButtonVisibility()
    }
    private fun cancelPending(){pendingPattern=null;pendingButtonId=null;pendingButtonName=null;pendingOcr=false;pendingWord=null;pendingActions.clear();pendingOcrScenarios.clear();editingActionIndex=null;removeMenu()}

    private fun showTapFeedback(x:Int,y:Int){val manager=wm?:return;val d=resources.displayMetrics.density;val size=(30*d).toInt();val v=View(this).apply{background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(0xAAFFFFFF.toInt())}};val p=WindowManager.LayoutParams(size,size,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,overlayFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START;x=x-size/2;y=y-size/2};try{manager.addView(v,p);v.animate().scaleX(1.8f).scaleY(1.8f).alpha(0f).setDuration(180).withEndAction{try{manager.removeView(v)}catch(_:Exception){}}.start()}catch(_:Exception){}}
}
