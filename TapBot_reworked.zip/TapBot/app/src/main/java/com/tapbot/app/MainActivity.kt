package com.tapbot.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private val expanded=mutableSetOf<String>()
    private val exportCode=2001
    private val importCode=2002

    override fun onCreate(state:Bundle?){super.onCreate(state);setContentView(R.layout.activity_main);list=findViewById(R.id.patternListContainer)
        findViewById<Button>(R.id.btnAccessibility).setOnClickListener{startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}
        findViewById<Button>(R.id.btnOverlay).setOnClickListener{startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))}
        val buttons=findViewById<CheckBox>(R.id.cbButtonEnabled);buttons.isChecked=PatternStore.getButtonEnabled(this);buttons.setOnCheckedChangeListener{_,v->PatternStore.setButtonEnabled(this,v);TapBotAccessibilityService.instance?.refreshButtonVisibility()}
        val adder=findViewById<CheckBox>(R.id.cbAdderEnabled);adder.isChecked=PatternStore.getAdderEnabled(this);adder.setOnCheckedChangeListener{_,v->PatternStore.setAdderEnabled(this,v);TapBotAccessibilityService.instance?.refreshButtonVisibility()}
        val resize=findViewById<CheckBox>(R.id.cbShowResizeHandle);resize.isChecked=PatternStore.getShowResizeHandle(this);resize.setOnCheckedChangeListener{_,v->PatternStore.setShowResizeHandle(this,v);TapBotAccessibilityService.instance?.refreshButtonVisibility()}
        findViewById<Button>(R.id.btnAddPattern).setOnClickListener{addPattern()}
        findViewById<Button>(R.id.btnExport).setOnClickListener{exportSettings()};findViewById<Button>(R.id.btnImport).setOnClickListener{importSettings()}
    }
    override fun onResume(){super.onResume();TapBotAccessibilityService.instance?.setSettingsScreenActive(true);render()}
    override fun onPause(){TapBotAccessibilityService.instance?.setSettingsScreenActive(false);super.onPause()}

    private fun render(){list.removeAllViews();PatternStore.loadPatterns(this).forEach{p->list.addView(patternCard(p))}}
    private fun patternCard(p:Pattern):View{
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,14,18,14);setBackgroundColor(0xFFF2F2F2.toInt())}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        header.addView(TextView(this).apply{text=(if(expanded.contains(p.name))"▼ " else "▶ ")+p.name+" · ${p.buttons.size}";textSize=16f;setTextColor(0xFF111111.toInt());layoutParams=LinearLayout.LayoutParams(0,-2,1f);setOnClickListener{if(!expanded.add(p.name))expanded.remove(p.name);render()}})
        val sw=android.widget.Switch(this).apply{isChecked=p.enabled;setOnCheckedChangeListener{_,v->val d=PatternStore.loadPatterns(this@MainActivity);d.find{it.name==p.name}?.enabled=v;PatternStore.savePatterns(this@MainActivity,d);TapBotAccessibilityService.instance?.refreshButtonVisibility()}}
        header.addView(sw);header.addView(small("✎"){renamePattern(p.name)});if(PatternStore.loadPatterns(this).size>1)header.addView(small("🗑"){deletePattern(p.name)});card.addView(header)
        if(expanded.contains(p.name)){
            p.buttons.forEach{b->val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(6,12,0,4)};row.addView(TextView(this).apply{text="${b.name}  ·  ${if(b.isOcr())"${b.ocrScenarios.size} слов" else "${b.actions.size} действ."}";textSize=14f;layoutParams=LinearLayout.LayoutParams(0,-2,1f);setTextColor(0xFF222222.toInt())});row.addView(small("Настроить"){TapBotAccessibilityService.instance?.openButtonForSettings(b.id)});row.addView(small("🗑"){deleteButton(p.name,b.id)});card.addView(row)}
            card.addView(Button(this).apply{text="+ Добавить кнопку";setOnClickListener{TapBotAccessibilityService.instance?.startCreateFor(p.name)}})
        }
        return card.apply{layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=12}}
    }
    private fun small(text:String,click:()->Unit)=TextView(this).apply{this.text=text;textSize=12f;setTextColor(0xFF111111.toInt());setPadding(12,8,12,8);setOnClickListener{click()}}
    private fun addPattern(){val input=EditText(this).apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES};AlertDialog.Builder(this).setTitle("Новый раздел").setView(input).setPositiveButton("Создать"){_,_->val n=input.text.toString().trim();if(n.isBlank())return@setPositiveButton;val d=PatternStore.loadPatterns(this);if(d.any{it.name==n}){Toast.makeText(this,"Такой раздел уже есть",Toast.LENGTH_SHORT).show();return@setPositiveButton};d.add(Pattern(n));PatternStore.savePatterns(this,d);expanded.add(n);render()}.setNegativeButton("Отмена",null).show()}
    private fun renamePattern(old:String){val input=EditText(this).apply{setText(old);inputType=InputType.TYPE_CLASS_TEXT};AlertDialog.Builder(this).setTitle("Название").setView(input).setPositiveButton("Сохранить"){_,_->val n=input.text.toString().trim();if(n.isBlank())return@setPositiveButton;val d=PatternStore.loadPatterns(this);if(n!=old&&d.any{it.name==n}){Toast.makeText(this,"Такое название уже есть",Toast.LENGTH_SHORT).show();return@setPositiveButton};d.find{it.name==old}?.name=n;PatternStore.savePatterns(this,d);if(expanded.remove(old))expanded.add(n);render()}.setNegativeButton("Отмена",null).show()}
    private fun deletePattern(n:String){AlertDialog.Builder(this).setTitle("Удалить «$n»?").setPositiveButton("Удалить"){_,_->val d=PatternStore.loadPatterns(this);d.removeAll{it.name==n};PatternStore.savePatterns(this,d);expanded.remove(n);render();TapBotAccessibilityService.instance?.refreshButtonVisibility()}.setNegativeButton("Отмена",null).show()}
    private fun deleteButton(pattern:String,id:String){AlertDialog.Builder(this).setTitle("Удалить кнопку?").setPositiveButton("Удалить"){_,_->val d=PatternStore.loadPatterns(this);d.find{it.name==pattern}?.buttons?.removeAll{it.id==id};PatternStore.savePatterns(this,d);render();TapBotAccessibilityService.instance?.refreshButtonVisibility()}.setNegativeButton("Отмена",null).show()}

    private fun exportSettings(){startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json";putExtra(Intent.EXTRA_TITLE,"tapbot-backup.json")},exportCode)}
    private fun importSettings(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json"},importCode)}
    override fun onActivityResult(req:Int,res:Int,data:Intent?){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data?.data==null)return;try{if(req==exportCode){contentResolver.openOutputStream(data.data!!)?.use{it.write(PatternStore.exportToJson(this).toByteArray())};Toast.makeText(this,"Готово",Toast.LENGTH_SHORT).show()}else if(req==importCode){val text=contentResolver.openInputStream(data.data!!)?.bufferedReader()?.readText();val n=PatternStore.importFromJson(this,text?:"");Toast.makeText(this,if(n>=0)"Импортировано: $n" else "Ошибка файла",Toast.LENGTH_SHORT).show();render();TapBotAccessibilityService.instance?.refreshButtonVisibility()}}catch(e:Exception){Toast.makeText(this,"Ошибка: ${e.message}",Toast.LENGTH_LONG).show()}}

    override fun onCreateOptionsMenu(menu:Menu):Boolean{menuInflater.inflate(R.menu.main_menu,menu);return true}
    override fun onOptionsItemSelected(item:MenuItem):Boolean{if(item.itemId==R.id.action_about){AlertDialog.Builder(this).setTitle("О программе").setMessage("TapBot — простая автоматизация касаний.\n\nАвтопоиск работает только после нажатия на соответствующую кнопку: сначала быстрый поиск текста через Accessibility, затем OCR при необходимости. Никакого постоянного сканирования экрана нет.").setPositiveButton("Закрыть",null).show();return true};return super.onOptionsItemSelected(item)}
}
